#This program tells you what have you entered
inp = input("Enter something\n", )

