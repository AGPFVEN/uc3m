n_one = int(input("Input one number: "))
n_two = int(input("Input one number: "))

if (n_two == 0):
    print("Cannot divide by zero")
else:
    print(n_one / n_two)