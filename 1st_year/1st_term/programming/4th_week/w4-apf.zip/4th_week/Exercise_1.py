#Given by the Exercise
a = 4
a += 2
print(a)
a -= 3
print(a)
a *= 3
print(a)
a /= 2
print(a)
a %= 4
print(a)
a == 0
print(a)
a //= 2
print(a)

"""This exercise consists in explaning how these assingning operators work
"+=" is used to asign and sum the left var with the right value or var
"-=" is used to asign and rest the left var with the right value or var
"*=" is used to asign and multiply the left var with the right value or var
"/=" is used to asign and divide the left var with the right value or var
"%=" is used to asign and uses the reminder the left var with the right value or var
"==" is not an assign operator
"//=" is used to asign the floor of the divition between left var with the right value or var
"""