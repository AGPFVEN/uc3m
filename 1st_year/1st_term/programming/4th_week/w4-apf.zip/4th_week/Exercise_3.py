a = 3
b = 8
c = 3.0
r = a == 0
s = a != 0
t = a <= b
u = b >= a
v = b > a
w = b < a
x = c == 3.0
print("r:", r)
print("s:", s)
print("t:", t)
print("u:", u)
print("v:", v)
print("w:", w)
print("x:", x)
"""
The program is comparing variables with constants (numbers)
and other variables so the result will be all boolean values (True or False)
"""