#This program will change the value of a variable from int to string

#Initializing the variable
change_var = 2

#Print the variable at the beginning and the type
print("change_var is %i of type" % change_var, str(type(change_var)))

#Change the value of variable
change_var = "Hello"

#Print the variable at the end and the type
print("change_var is %s of type" % change_var, str(type(change_var)))

#It doesn't matter the type of the varieble when you change it's value
#This propperty is named Dynamic typing