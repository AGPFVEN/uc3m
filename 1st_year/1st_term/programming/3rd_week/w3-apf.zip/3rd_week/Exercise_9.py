#This program demonstrates how string concatenation works in python

first_string = "Hello"
second_string = "World"
third_string = first_string + second_string

print(third_string)

#This happens because of the string operators that python allows
#Trying to use the symbol "-" is not supported by python, so it will
#pop up an error