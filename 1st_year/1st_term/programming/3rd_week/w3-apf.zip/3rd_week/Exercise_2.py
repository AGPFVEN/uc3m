#This variable will pop up an error

error_variable

#The error is NameError: name 'error_variable' is not defined"SyntaxError: invalid syntax"
#It is shown because a variable without value can't be stored in memory