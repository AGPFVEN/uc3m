#This program shows how to store strigs in the most strange way

twinkle_twinkle = """Twinkle, twinkle, little star,
    how I wonder what you are!
        Up above the world so high,
        like a diamond in the sky.
Twinkle, twinkle, little star,
    how I wonder what you are."""

print(twinkle_twinkle)