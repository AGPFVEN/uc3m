#This program aims to demonstrate the reaction of python when dividing by 0
first_int = 5
second_int = 0
third_int = first_int / second_int

print("ZeroDivisionError: division by zero")

#This happens because of how python works
#This response is the same with floats