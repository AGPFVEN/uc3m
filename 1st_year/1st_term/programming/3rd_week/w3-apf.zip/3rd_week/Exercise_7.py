#This program aims to demonstrate the independence of variables

#Declaring two variables 
original_variable = 2
copied_variable = original_variable

#Print the copied variable
print(copied_variable)

#changing the original variable
original_variable = 3

#Printing again the copied variable
print(copied_variable)

#The copied variable tooks the value of the original one and then
#it becomes independent of the original one