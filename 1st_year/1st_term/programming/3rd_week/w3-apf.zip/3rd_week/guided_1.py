"""This is the first guided exercie"""



first_part = """Given the current situation that King’s Landing is facing, the House """
second_part = """is asking for your economic services because
of the following cause."""
third_part = """
The estimated total quantity is"""
fourth_part = """gold coins. The loan will be returned during the """
fifth_part = """> following years with
"""
seventh_part = """I hope the bank will consider this proposal because the House"""



print("In this program I will help you to fill the form to ask money")
first_input = input("Please enter the name of the house ")


second_input = input("")

third_input = input("")

fourth_input = input("")


fifth_input = input("")

sixth_input = input("")

seventh_input = input("")

eighth_input = input("")