#This program just declares all the variables types
_integer = 2
_float = 2.1
_bool = True
_string = "This is a string"

#The propperty which allow us to declare variables without specifying them is called
#Dynamic typing