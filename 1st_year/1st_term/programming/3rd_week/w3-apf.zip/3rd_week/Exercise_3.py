#This program will change the value of a variable

#Initializing the variable
change_var = 2

#Print the variable at the beginning and the type
print("change_var is %i of type" % change_var, str(type(change_var)))

#Change the value of variable
change_var = 2.5

#Print the variable at the end and the type
print("change_var is %f of type" % change_var, str(type(change_var)))

#It doesn't matter the type of the varieble when you change it's value