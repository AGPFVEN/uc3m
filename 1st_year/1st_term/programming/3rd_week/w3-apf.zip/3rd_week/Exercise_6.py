#Declaring two variables in one line is possible because it's linked a lot with C++
first_var = 1; second_var = 2; third_var = 3

#There's an alternative way more elegant
first_var, second_var, third_var = 1, 2, 3