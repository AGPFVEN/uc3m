#Creating the lists
list_1 = [0, 1]

#Assinging values
list_1[1] = list_1[0]
print(list_1)

#Change value
list_1[0] = 2
print(list_1)