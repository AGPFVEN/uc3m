#include <stdio.h>
#include "queue.c"

int main(int argc, char *argv[]){
    struct queue *my_queue =  queue_init(5);
    queue_put(*my_queue, )

    printf("test\n");
}