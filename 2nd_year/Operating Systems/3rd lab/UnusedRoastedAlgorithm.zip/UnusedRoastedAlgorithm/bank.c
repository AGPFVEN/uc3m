// OS-P3 2022-2023

#include "queue.h"
#include <fcntl.h>
#include <pthread.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define MAX_OPERATIONS 200

// all the global variables
char list_client_ops[MAX_OPERATIONS][50]; // two-dimensional array of characters
int client_numop = 1;                     // +1 each time an atm does something
int bank_numop; // +1 each time a worker does something
int global_balance;
struct queue *circular_buffer;

pthread_mutex_t mutex_atm; // mutex for client_num_op

/**
 * Entry point
 * @param argc
 * @param argv
 * @return
 */

void ATM() {
  struct element inserts;

  int a = pthread_mutex_lock(&mutex_atm);
   if (a != 0) {
    perror("Error lock mutex");
    exit(-1);
  }
  
  char *token = strtok(list_client_ops[client_numop], " ");

  char first_letter = list_client_ops[client_numop][0];

  //General operations (allways done)
  inserts.what = first_letter;
  token = strtok(NULL, " ");
  inserts.to_who = atoi(token);

  //Create
  if (first_letter == 'C') {
    inserts.by_who = 0;
    inserts.how_much = 0;

  //Deposit
  } else if (first_letter == 'D') {
    token = strtok(NULL, " ");
    inserts.how_much = atoi(token);
    token = strtok(NULL, " ");
    inserts.by_who = 0;

    //Transfer
  } else if (first_letter == 'T') {
    token = strtok(NULL, " ");
    inserts.by_who = atoi(token);
    token = strtok(NULL, " ");
    inserts.how_much = atoi(token);
  }

  //Withdrawal
  else if (first_letter == 'W') {
    token = strtok(NULL, " ");
    inserts.how_much = atoi(token);
    token = strtok(NULL, " ");
    inserts.by_who = 0;
  }

  //Balance
  else if (first_letter == 'B') {
    inserts.by_who = 0;
    inserts.how_much = 0;
  }

  int b = queue_put(circular_buffer, &inserts);
  if (b < 0) {
    perror("Error queue put");
    exit(-1);
  }

  client_numop++;

  if (pthread_mutex_unlock(&mutex_atm) < 0) {
    perror("Error unlock mutex");
    exit(-1);
  }
  print_queue(circular_buffer);
}

struct element Worker(){
  struct element *worker_element = queue_get(circular_buffer);

  if (worker_element->what == 'D'){
    global_balance = global_balance + worker_element->how_much;
  } else if (worker_element->what == 'W'){ 
    global_balance = global_balance - worker_element->how_much;
  } 

  print_queue(circular_buffer);
  return *worker_element;
}

int main(int argc, const char *argv[]) {
  // Check if arguments number is correct
  if (argc != 6) {
    printf("Invalid number of arguments\n");
    return -1;
  }

  //Create queue
  circular_buffer = queue_init(atoi(argv[5]));

  // Open file with file descriptor
  int lines = 0;
  FILE *file;
  int numero1;
  char c;
  int row = 0;

  // char words[MAX_OPERATIONS][MAX_WORDS_PER_OP][MAX_WORD_LENGTH];

  file = fopen(argv[1], "r");

  if (fscanf(file, "%d", &numero1) != 1) {
    printf("Error reading file.\n");
    return -1;
  }

  if (file) {
    while ((c = fgetc(file)) != EOF) {
      if (c == '\n') {
        lines++;
        list_client_ops[row][strlen(list_client_ops[row])] = c;
        row++; // move to the next row
      } else {
        list_client_ops[row][strlen(list_client_ops[row])] =
            c; // assign c to the current element of list_client_ops
      }
    }
    fclose(file);
    printf("The file has %d lines.\n", lines + 1);
  } else {
    printf("Failed to open the file.\n");
  }

  if (numero1 != (lines - 1)) {
    printf("Incorrect number of operations\n");
    return -1;
  }

  // Print the list_client_ops array

  //printf("The list of operations is:\n");
  //for (int i = 0; i < lines; i++) {
    //printf("%d\n", i);
    //printf("%s\n", list_client_ops[i]);
  //}

  for (int i = 0; i < 12; i++){
    printf("1 atm\n");
    ATM();
    printf("Number of items in queue: %d\n\n", circular_buffer->elements_in);
    //sleep(6);
  }

  for (int i = 0; i < 1; i++){
    printf("1 worker\n");
    struct element my_elem = Worker();
    printf("%c, %d\n", my_elem.what, my_elem.to_who);
    printf("Number of items in queue: %d\n\n", circular_buffer->elements_in);
    //sleep(6);
  }

  return 0;
}
